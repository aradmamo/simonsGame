import React from "react";
import Simons from "./components/Simons";
function App() {
  return <Simons />;
}
export default App;
